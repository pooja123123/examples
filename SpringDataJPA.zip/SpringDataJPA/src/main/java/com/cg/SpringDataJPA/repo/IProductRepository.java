package com.cg.SpringDataJPA.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.SpringDataJPA.beans.Product;
@Repository("productrepo")
public interface IProductRepository extends CrudRepository<Product, String>{

}
