package com.cg.SpringDataJPA.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SpringDataJPA.beans.Product;
import com.cg.SpringDataJPA.repo.IProductRepository;
@Service
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepository repo;

	@Override
	public List<Product> getAllProduct() {
		List<Product> list=new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		
		return repo.findById(id);
	}

	@Override
	public void addProduct(Product product) {
		repo.save(product);
		
	}

	@Override
	public void updateProduct(Product product, String id) {
         repo.save(product);		
	}

	@Override
	public void deleteProduct(String id) {
         repo.deleteById(id);		
	}

}
