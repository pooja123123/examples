package com.cg.SpringDataJPA.Exception;

public interface ProductException {
String ERROR1="ID NOT FOUND";
}
