package com.cg.SpringDataJPA.service;

import java.util.List;
import java.util.Optional;

import com.cg.SpringDataJPA.beans.Product;

public interface IProductService {
	
	public List<Product> getAllProduct();

	public Optional<Product> getProductById(String id);

	public void addProduct(Product product);

	public void updateProduct(Product product, String id);

	public void deleteProduct(String id);

}
