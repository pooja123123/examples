package com.cg.SpringDataJPA.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SpringDataJPA.Exception.ProductException;
import com.cg.SpringDataJPA.Exception.ProductExceptionC;
import com.cg.SpringDataJPA.beans.Product;
import com.cg.SpringDataJPA.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	private IProductService service;

	@RequestMapping("/show")
	public List<Product> showProduct() {
		return service.getAllProduct();
	}

	@RequestMapping("/product/{id}")
	public Optional<Product> getProductById(@PathVariable int id) {
		return service.getProductById(id);
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public void addProduct(@RequestBody Product product) {
		service.addProduct(product);

	}

	@ExceptionHandler(ProductExceptionC.class)
	@DeleteMapping(value = "/delete/{id}")
	public String deleteProduct(@PathVariable int id) throws ProductExceptionC {
		try {
			return service.deleteProduct(id);
		} catch (Exception e) {
			return ProductException.ERROR1;
		}
	}
	@ExceptionHandler(ProductExceptionC.class)
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public String updateProduct(@RequestBody Product product, @PathVariable int id)throws ProductExceptionC {
		try {
			return service.updateProduct(product, id);
		} catch (Exception e) {
			return ProductException.ERROR1;
		}

	}

}
