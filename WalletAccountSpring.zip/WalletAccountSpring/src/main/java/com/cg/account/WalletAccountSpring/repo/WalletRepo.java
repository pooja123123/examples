package com.cg.account.WalletAccountSpring.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.account.WalletAccountSpring.entities.Customer;

@Repository("Customerrepo")
public interface WalletRepo extends CrudRepository<Customer, String> {

	
}
