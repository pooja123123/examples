package com.cg.account.WalletAccountSpring.entities;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Wallet {
	@Column(name = "BALANCE", length = 20)
	private BigDecimal balance = new BigDecimal("0");

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return " balance=" + balance;
	}
}