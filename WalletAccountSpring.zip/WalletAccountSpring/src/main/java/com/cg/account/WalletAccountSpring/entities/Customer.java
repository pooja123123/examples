package com.cg.account.WalletAccountSpring.entities;

import java.math.BigDecimal;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Customer {

	private String name;
	@Id
	private String mobileNo;
	@Embedded
	private Wallet wallet;

	public Customer() {
		wallet = new Wallet();
	}

	public BigDecimal getWalletBalance() {
		return wallet.getBalance();
	}

	public void setWalletBalance(BigDecimal amount) {
		wallet.setBalance(amount);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

}
