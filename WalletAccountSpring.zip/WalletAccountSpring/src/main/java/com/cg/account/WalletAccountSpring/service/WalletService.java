package com.cg.account.WalletAccountSpring.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import com.cg.account.WalletAccountSpring.entities.Customer;
import com.cg.account.WalletAccountSpring.entities.Transaction;

public interface WalletService {
	public void addAccount(Customer customer);

	public Optional<Customer> showBalance(String mobnum);

	public Customer transferFund(String mobile, String rmobile, BigDecimal balance);

	public Customer depositBalance(String mobnum, BigDecimal balance);

	public Customer withdrawal(String mobnum, BigDecimal amount2);
	
	public List<Transaction> printTransactions(String mobile);

}
