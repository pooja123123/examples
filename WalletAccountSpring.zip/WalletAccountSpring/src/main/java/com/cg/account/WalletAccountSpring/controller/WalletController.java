package com.cg.account.WalletAccountSpring.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.account.WalletAccountSpring.entities.Customer;
import com.cg.account.WalletAccountSpring.entities.Transaction;
import com.cg.account.WalletAccountSpring.service.WalletService;

@RestController
public class WalletController {
	@Autowired
	private WalletService service;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public void addProduct(@RequestBody Customer customer) {
		service.addAccount(customer);

	}

	@RequestMapping(value = "/showbalance/{mobile}")
	public Optional<Customer> showCustomerBalance(@PathVariable String mobile) {
		return service.showBalance(mobile);
	}

	@RequestMapping(value = "/depositbalance/{mobile}/{balance}", method = RequestMethod.PUT)
	public Customer depositBalance(@PathVariable String mobile, @PathVariable BigDecimal balance) {
		return service.depositBalance(mobile, balance);
	}

	@RequestMapping(value = "/withdraw/{mobile}/{balance}", method = RequestMethod.PUT)
	public Customer withdraw(@PathVariable String mobile, @PathVariable BigDecimal balance) {
		return service.withdrawal(mobile, balance);
	}

	@RequestMapping(value = "/fundtransfer/{mobile}/{rmobile}/{balance}", method = RequestMethod.PUT)
	public Customer fundtransfer(@PathVariable String mobile, @PathVariable String rmobile,
			@PathVariable BigDecimal balance) {
		return service.transferFund(mobile, rmobile, balance);
	}

	@RequestMapping("/showtransaction/{mobile}")
	public List<Transaction> showTransactions(@PathVariable String mobile) {
		return service.printTransactions(mobile);

	}

}
