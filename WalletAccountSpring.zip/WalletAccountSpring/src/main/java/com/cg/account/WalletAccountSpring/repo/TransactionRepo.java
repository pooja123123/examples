package com.cg.account.WalletAccountSpring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.account.WalletAccountSpring.entities.Transaction;


@Repository("Transactionrepo")
public interface TransactionRepo extends CrudRepository<Transaction, String> {

	

}
