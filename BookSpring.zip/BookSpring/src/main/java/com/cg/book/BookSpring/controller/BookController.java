package com.cg.book.BookSpring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.book.BookSpring.entity.Book;
import com.cg.book.BookSpring.service.BookService;

@RestController
@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Book With this ID not present")

public class BookController {
	@Autowired
	BookService bookserv;

	@RequestMapping("/show")
	public List<Book> showProduct() {
		return bookserv.showAllBook();
	}
	
	@RequestMapping(value="/add" , method = RequestMethod.POST)
	public void addBook(@RequestBody Book book) {
		bookserv.addBook(book);
	}
	@ExceptionHandler({Exception.class})
	@RequestMapping("/display/{id}")
	public Optional<Book> displayBookById(@PathVariable int id) {
		return bookserv.getBookById(id);
	}
	
	@DeleteMapping(value = "/delete/{id}")
	public void deleteBook(@PathVariable int id) {
		bookserv.deleteBook(id);
	}
	
	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public void updateProduct(@RequestBody Book book, @PathVariable int id) {
		bookserv.updateBookName(book, id);

	}
}
