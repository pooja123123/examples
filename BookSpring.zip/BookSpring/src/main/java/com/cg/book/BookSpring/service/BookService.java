package com.cg.book.BookSpring.service;

import java.util.List;
import java.util.Optional;

import com.cg.book.BookSpring.entity.Book;

public interface BookService {

	public void addBook(Book book);

	public List<Book> showAllBook();

	void updateBookName(Book book, int id);

	Optional<Book> getBookById(int id);

	void deleteBook(int id);

}
