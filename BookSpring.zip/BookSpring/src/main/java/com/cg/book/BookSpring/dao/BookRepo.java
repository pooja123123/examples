package com.cg.book.BookSpring.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.book.BookSpring.entity.Book;

@Repository("BookRepo")
public interface BookRepo extends CrudRepository<Book, Integer>{

}
