package com.cg.book.BookSpring.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.BookSpring.dao.BookRepo;
import com.cg.book.BookSpring.entity.Book;

@Service("bookservice")
public class BookServiceImpl implements BookService {
	@Autowired
	BookRepo repo;

	@Override
	public void addBook(Book book) {

		repo.save(book);
	}

	@Override
	public List<Book> showAllBook() {
		List<Book> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;

	}

	@Override
	public Optional<Book> getBookById(int id) {
		return repo.findById(id);

	}

	@Override
	public void updateBookName(Book book, int id) {
		repo.save(book);
	}

	@Override
	public void deleteBook(int id) {
		repo.deleteById(id);

	}


}
