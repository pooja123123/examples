package com.cg.book.BookSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.book.BookSpring")
public class BookSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookSpringApplication.class, args);
	}
}
