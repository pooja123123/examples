package com.cg.author.service;

import com.cg.author.entities.Author;

public interface AuthorService {

	public abstract void addAuthor(Author author);

	public abstract Author findById(int id1);



	public abstract void updateDetails(Author author);

	public abstract void removeAuthor(Author author);

}
