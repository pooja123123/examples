package com.cg.author.dao;

import com.cg.author.entities.Author;

public interface Authordao {

	void addAuthorDao(Author author);

	void beginTransaction();

	void commitTransaction();

	Author findById(int id1);

	void updateDetails(Author author);

	void removeDetails(Author author);

}
